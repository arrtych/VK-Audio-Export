# VK-Audio-Export
Export tool for audios in VK.com before audio API closing.

Welcome Screen:
![Welcome Screen](https://raw.githubusercontent.com/4matic/VK-Audio-Export/master/docs/img/welcome.PNG)

Main Screen:
![Main Screen](https://raw.githubusercontent.com/4matic/VK-Audio-Export/master/docs/img/responsive_main.PNG)


To try it:
`git clone https://github.com/4matic/VK-Audio-Export.git`

Then go to:

1. Chrome -> More Tools -> Extensions
2. Load unpacked extension...
3. Choose cloned repository with manifest.json at root.


